# Databricks notebook source
print('My name is Stanislav')
